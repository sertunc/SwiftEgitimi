import UIKit

func toplama(deger1:Int,deger2:Int)->Int{
    return deger1+deger2;
}

var sonuc = toplama(deger1: 1, deger2: 2);

print("Toplama İşleminin Sonucu: \(sonuc)");
